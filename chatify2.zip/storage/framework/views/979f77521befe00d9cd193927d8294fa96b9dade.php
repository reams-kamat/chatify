
<div class="avatar av-l upload-avatar-preview" style="background-image: url('<?php echo e(asset('/storage/'.config('chatify.user_avatar.folder').'/'.Auth::user()->avatar)); ?>');"></div>
<!-- <p class="info-name"><?php echo e(config('chatify.name')); ?></p> -->
<p class="info-name"><?php echo e(Auth::user()->name); ?></p>
<div>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('profile.show')).'','style' => 'color: #aeaeb7 !important']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('profile.show')).'','style' => 'color: #aeaeb7 !important']); ?>
		<?php echo e(__('Profile')); ?>

	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<form method="POST" action="<?php echo e(route('logout')); ?>">
		<?php echo csrf_field(); ?>

		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
		this.closest(\'form\').submit();','style' => 'color: red !important']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
		this.closest(\'form\').submit();','style' => 'color: red !important']); ?>
			<?php echo e(__('Log Out')); ?>

		 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	</form>
</div>


<?php /**PATH E:\laravel\chatify\resources\views/vendor/Chatify/layouts/accountinfo.blade.php ENDPATH**/ ?>